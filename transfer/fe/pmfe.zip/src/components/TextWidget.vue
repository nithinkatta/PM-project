<template>
  <div>
    <nav class="nav">
      <h1>
        Home Page
      </h1>
    </nav>
    <div class="text-widget">
      <div class="add-block" v-if="auth == 'admin'">
        <input v-model="newBlockTitle" type="text" placeholder="Block Title" class="input" />
        <button @click="addBlock" class="button is-primary">Add Block</button>
      </div>
      <div class="block-list">
        <widget-block
        v-for="(block, index) in widgetBlocks"
        :key="block.id"
        :title="block.title"
        :widgets="block.widgets"
        @add-widget="addWidgetToBlock(index, $event)"
        @update-title="updateBlockTitle(index, $event)"
        @delete-block="deleteBlock(index)"
        :auth="auth"
        />
      </div>
      <MileStone :auth="auth"/>
      <!-- <UrgentTasks :auth="auth"/> -->
    </div>
  </div>
</template>

<script>
import WidgetBlock from './WidgetComp.vue';
import MileStone from './MileStone.vue';
// import UrgentTasks from './UrgentTasks.vue';
export default {
  data() {
    return {
      widgetBlocks: [],
      newBlockTitle: ''
    };
  },
  created() {
    this.fetchWidgetBlocks();
  },
  props: {
    auth: String
  },
  methods: {
    fetchWidgetBlocks() {
      fetch('http://localhost:3000/api/blocks')
        .then(response => response.json())
        .then(data => {
          this.widgetBlocks = data.map(block => ({
            ...block,
            widgets: []
          }));
          this.widgetBlocks.forEach(block => this.fetchWidgetsForBlock(block.id));
        });
    },
    fetchWidgetsForBlock(blockId) {
      fetch(`http://localhost:3000/api/blocks/${blockId}/widgets`)
        .then(response => response.json())
        .then(widgets => {
          const block = this.widgetBlocks.find(b => b.id === blockId);
          if (block) {
            block.widgets = widgets;
          }
        });
    },
    addWidgetToBlock(blockIndex, widget) {
      const blockId = this.widgetBlocks[blockIndex].id;
      fetch(`http://localhost:3000/api/blocks/${blockId}/widgets`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(widget)
      })
      .then(response => response.json())
      .then(newWidget => {
        this.widgetBlocks[blockIndex].widgets.push(newWidget);
      });
    },
    addBlock() {
      if (this.newBlockTitle) {
        fetch('http://localhost:3000/api/blocks', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ title: this.newBlockTitle })
        })
        .then(response => response.json())
        .then(newBlock => {
          this.widgetBlocks.push({ ...newBlock, widgets: [] });
          this.newBlockTitle = '';
        });
      }
    },
    updateBlockTitle(blockIndex, newTitle) {
      const blockId = this.widgetBlocks[blockIndex].id;
      fetch(`http://localhost:3000/api/blocks/${blockId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ title: newTitle })
      })
      .then(response => response.json())
      .then(updatedBlock => {
        this.widgetBlocks[blockIndex].title = updatedBlock.title;
      });
    },
    deleteBlock(blockIndex) {
      const blockId = this.widgetBlocks[blockIndex].id;
      fetch(`http://localhost:3000/api/blocks/${blockId}`, {
        method: 'DELETE'
      })
      .then(() => {
        this.widgetBlocks.splice(blockIndex, 1);
      });
    }
  },
  components: {
    WidgetBlock,
    MileStone,
    // UrgentTasks
  }
};
</script>

<style scoped>
.nav{
  background-color: #007bff;
  color: white;
  padding: 10px;
  text-align: center;
}
.text-widget {
  padding: 20px;
  min-width: 100vh;
  background-color: #f9f9f9;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.block-list {
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  margin-bottom: 20px;
  /* width: 550px;
  border: 1px solid #ddd; */
}

.add-block {
  display: flex;
  gap: 10px;
  margin-top: 20px;
}

.input {
  padding: 8px 12px;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-size: 16px;
}

.button {
  padding: 8px 16px;
  font-size: 16px;
  cursor: pointer;
  border: none;
  border-radius: 4px;
  color: #fff;
  background-color: #007bff;
  transition: background-color 0.3s ease;
}

.button.is-primary {
  background-color: #007bff;
}

.button:hover {
  background-color: #0056b3;
}
</style>
