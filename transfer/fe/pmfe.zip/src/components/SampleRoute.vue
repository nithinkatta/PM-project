<template>
  <div>
    {{ message }}
  </div>
</template>

<script>
export default {
    props:['message']
}
</script>

<style>

</style>