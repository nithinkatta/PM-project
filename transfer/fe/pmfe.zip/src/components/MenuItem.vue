<template>
  <div class="menu-item" :class="{ opened: expanded, selected: isSelected }">
    <div
      class="label"
      @click="handleClick()"
      :style="{ paddingLeft: depth * 20 + 20 + 'px' }"
    >
      <div class="left">
        <i v-if="icon" class="material-icons-outlined">{{ icon }}</i>
        <span v-if="showLabel">{{ label }}</span>
      </div>
      <div v-if="data && data.length > 0" class="right">
        <i class="expand material-icons" :class="{ opened: expanded }">expand_more</i>
      </div>
    </div>
    <div
      v-show="showChildren"
      :class="{ 'small-menu': smallMenu }"
      class="items-container"
      :style="{ height: containerHeight }"
      ref="container"
    >
      <MenuItem
        :class="{ opened: showChildren, selected: isSelected }"
        v-for="(item, index) in data"
        :key="index"
        :id="item.id"
        :data="item.children"
        :label="item.label"
        :type="item.type"
        :icon="item.icon"
        :depth="depth + 1"
        :smallMenu="smallMenu"
        :selected-id="selectedId"
        :auth="auth" 
        @update-selected="updateSelected"
      />
    </div>
  </div>
</template>

<script>
import { useStore } from "../store";

export default {
  name: "MenuItem",
  props: {
    id: {
      type: Number,
    },
    data: {
      type: Array,
    },
    label: {
      type: String,
    },
    icon: {
      type: String,
    },
    depth: {
      type: Number,
    },
    smallMenu: {
      type: Boolean,
    },
    type: {
      type: String,
      default: 'file'
    },
    selectedId: {
      type: Number,
    },
    auth:{
      type: String
    }
  },
  data() {
    return {
      showChildren: false,
      expanded: false,
      containerHeight: 0,
      isSelected: false,
      store: useStore(),
    };
  },
  watch: {
    selectedId(newVal) {
      this.isSelected = this.id === newVal;
    },
  },
  computed: {
    showLabel() {
      return this.smallMenu ? this.depth > 0 : true;
    },
  },
  methods: {
    handleClick() {
      this.$emit('update-selected', this.id);
      this.isSelected = true;

      const store = useStore();
      store.updateData(this.label);
      store.updateType(this.type);
      store.updateID(this.id);

      if (this.type === 'file') {
        if(this.auth == 'admin')
        {
          this.$router.push({
            path: `/projects/${this.id}`,
            query: {
              name: this.label,
              // id: this.id
            }
          });
        }
        else
        {
          this.$router.push({
            path: `/user/projects/${this.id}`,
            query: {
              name: this.label,
              // id: this.id
            }
          });
        }
      } else {
        this.toggleMenu();
      }
    },
    toggleMenu() {
      this.expanded = !this.expanded;
      if (!this.showChildren) {
        this.showChildren = true;
        this.$nextTick(() => {
          this.containerHeight = this.$refs["container"].scrollHeight + "px";
          setTimeout(() => {
            this.containerHeight = "fit-content";
            if (navigator.userAgent.indexOf("Firefox") != -1) 
              this.containerHeight = "-moz-max-content";
            this.$refs["container"].style.overflow = "visible";
          }, 300);
        });
      } else {
        this.containerHeight = this.$refs["container"].scrollHeight + "px";
        this.$refs["container"].style.overflow = "hidden";
        setTimeout(() => {
          this.containerHeight = 0 + "px";
        }, 10);
        setTimeout(() => {
          this.showChildren = false;
        }, 300);
      }
    },
    updateSelected(id) {
      this.$emit('update-selected', id);
    }
  },
};
</script>

<style scoped lang="scss">
.menu-item {
  position: relative;
  width: 100%;

  .label {
    width: 100%;
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    white-space: nowrap;
    user-select: none;
    height: 50px;
    padding: 0 20px;
    box-sizing: border-box;
    font-size: 14px;
    color: #6a6a6a;
    transition: all 0.3s ease;

    > div {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    i {
      font-size: 20px;
      color: #6e6e6e;
      transition: all 0.3s ease;

      &.expand {
        font-size: 16px;
        color: #cacaca;

        &.opened {
          transform: rotate(180deg);
        }
      }
    }

    &:hover {
      background: #deedff;
      cursor: pointer;
    }

    &.selected {
      background: #2382ee;
      font-weight: bold;
    }
  }

  .items-container {
    width: 100%;
    left: calc(100% + 6px);
    transition: height 0.3s ease;
    overflow: hidden;

    &.small-menu {
      width: fit-content;
      position: absolute;
      background: #fff;
      box-shadow: 0 0 10px #ebebeb;
      top: 0;

      .label {
        width: 100% !important;
        padding-left: 20px !important;
      }
    }
  }
}
</style>
